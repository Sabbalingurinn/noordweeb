# Asset credits

Hero photo: [Point3D Commercial Imaging on Unsplash](https://unsplash.com/photos/white-bed-linen-on-bed-oxeCZrodz78). Downloaded 25 September 2026 under the [Unsplash License](https://unsplash.com/license). The scene is stock imagery, not a photo of the fictional business. Replace it with imagery the real customer owns or is licensed to use. Do not sell the unmodified photo as a standalone product.

DM Sans, Manrope and Newsreader are redistributed under their included SIL Open Font License files. Fonts and images are served locally.
